from django.conf.urls import url,include
from . import views
from library.admin import UserAdmin

urlpatterns = [
    url(r'^admin/', views.login, name='login'),
    url(r'^', include(UserAdmin.urls)),
    url(r'^$', views.welcome, name='welcome'),
]