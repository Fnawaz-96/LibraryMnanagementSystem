# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from .models import Books

def login(request):
    return render(request, 'library/login.html',{})

def welcome(request):
    return render(request, 'library/welcome.html',{})